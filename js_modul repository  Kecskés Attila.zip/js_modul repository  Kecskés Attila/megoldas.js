// 1. feladat
function TeglaTestFelszin(a, b, c) {
    return 2 * (a * b + a * c + b * c);
}

// 2. feladat
function TeglaTestTerfogat(a, b, c) {
    return a * b * c;
}

// 3. feladat
function PhErtek(ertek) {
    if (ertek === 7) {
        return 'semleges';
    }
    if (ertek < 7) {
        return 'savas';
    }
    return 'lugos';
}

// 4. feladat
function ElsoNSzamOsszege(n) {
    let osszeg = 0;
    for (let i = 1; i <= n; i++) {
        osszeg += i;
    }
    return osszeg;
}

// 5. feladat
function PrimekSzama(szamok) {
    let db = 0;
    for (let szam of szamok) {
        if (PrimE(szam)) {
            db++;
        }
    }
    return db;
}

function PrimE(szam) {
    if (szam < 2) return false;
    for (let i = 2; i <= Math.sqrt(szam); i++) {
        if (szam % i === 0) return false;
    }
    return true;
}

// 6. feladat
function EkezetesBetukSzama(szoveg) {
    const ekezetesek = 'áéíóöőúüűÁÉÍÓÖŐÚÜŰ';
    let db = 0;
    for (let betu of szoveg) {
        if (ekezetesek.includes(betu)) {
            db++;
        }
    }
    return db;
}

// 7. feladat
function SzamVisszafele(szam) {
    return parseInt(szam.toString().split('').reverse().join(''));
}
